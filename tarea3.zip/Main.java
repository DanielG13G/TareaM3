/*
Crear una clase Libro que contenga los siguientes atributos: título, autor, año de publicación, género y disponibilidad 
(booleano que indica si el libro está prestado o no).
Implementar un constructor en la clase Libro para inicializar los atributos.
Crear una clase Biblioteca que contenga una lista de objetos Libro.
Implementar métodos en la clase Biblioteca para realizar las siguientes operaciones:
Agregar un nuevo libro a la biblioteca.
Buscar libros por título o autor y mostrar los resultados.
Prestar un libro (actualizando su disponibilidad).
Devolver un libro (actualizando su disponibilidad).
Mostrar información detallada de todos los libros disponibles en la biblioteca.
Crear una clase Main que sirva como punto de entrada del programa. En el método main, 
los estudiantes deben crear una instancia de la clase Biblioteca y realizar pruebas de todas las operaciones implementadas.
*/


// Tuve un problema en mi codigo y ya no me funciona pero aqui esta todo lo que hice 

public class Main {
    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();

        // Agregar algunos libros
        biblioteca.agregarLibro(new Libro("Cien años de soledad", "Gabriel García Márquez", 1967, "Realismo mágico"));
        biblioteca.agregarLibro(new Libro("El nombre de la rosa", "Umberto Eco", 1980, "Novela histórica"));
        biblioteca.agregarLibro(new Libro("1984", "George Orwell", 1949, "Distopía"));

 
        biblioteca.mostrarLibrosDisponibles();
        biblioteca.buscarPorTitulo("1984");
        biblioteca.prestarLibro("Cien años de soledad");
        biblioteca.devolverLibro("El nombre de la rosa");
        biblioteca.mostrarLibrosDisponibles();
    }
}

class Libro {
    private String titulo;
    private String autor;
    private int anioPublicacion;
    private String genero;
    private boolean prestado;

 r
    public Libro(String titulo, String autor, int anioPublicacion, String genero) {
        this.titulo = titulo;
        this.autor = autor;
        this.anioPublicacion = anioPublicacion;
        this.genero = genero;
        this.prestado = false; 
    }

     public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public boolean estaPrestado() {
        return prestado;
    }

    public void prestarLibro() {
        prestado = true;
    }

    public void devolverLibro() {
        prestado = false;
    }

     public void mostrarDetalles() {
        System.out.println("Título: " + titulo);
        System.out.println("Autor: " + autor);
        System.out.println("Año de publicación: " + anioPublicacion);
        System.out.println("Género: " + genero);
        System.out.println("Disponibilidad: " + (prestado ? "Prestado" : "Disponible"));
    }
}